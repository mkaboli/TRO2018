"""
================================================================================
CLASS ACTIVEEXPLORER
ACTIVE EXPLORATION FOR ONE OBJECT WITH 3 ACTIONS
CURRENT IMPLEMENTATION: 5 OBJECTS MULTICLASS 
THREE METHODS: RANDOM, EXPECTED ENTROPY, EXPECTED CONFUSION REDUCTION
GIVEN: OBJECT LOCATION, POSITIONING FINISHED

___USER CASE___
THE ROBOT HAS LEARNED SOME ALL OBJECTS. NOW THE OBJECTS ARE 
PLACED IN UNSTRUCTURED ENVIRONMENT, THE ROBOT NEEDS TO DETECT ONE OBJECT
AS QUICKLY AS POSSIBLE.

AUTHOR: Mohsne Kaboli
        TECHNICAL UNIVERITY OF MUNICH
        mohsen.kaboli@tum.de
        @2016
================================================================================
INPUT:
- method: exploration strategies
          1. random
          2. expected entropy
          3. confusion reduction

- online: if set True, online exploration, otherwise generate synthetic data
- prior_path: define the path to load prior knowledge.
              (either uniform data, or data learned from activeLearner) 
RESULTS:
- object belief: self.priors

STOPCONDITIONS:
- self.stop_thr, max_ = 0.9, min = 0.1
  if obj_MAP>0.9, object found;
  if obj_MAP<0.1, object rejected.

TO START EXPLORATION:
  ae = activeExplorer(method=3,online=True)
  ae.activeTouch(obs_obj=2)

TO EVALUATE THE ALGORITHMS' PERFORMANCE
  ae = activeExplorer(online=False)
  ae.evalActiveTouch(trails=100,metric='rej_steps')
___________________________________________________________________________________
"""
#print(__doc__)
import numpy as np
import numpy.matlib as matlab
import matplotlib.pyplot as plt
from scipy import stats
from sklearn import datasets
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
np.set_printoptions(linewidth=10000000)

class activeExplorer:

  def __init__(self, method=2, online=False, prior_path=None, debug=True): 
    ### static parameter ### 
    self.debug = debug
    self.prior_path = prior_path
    self.online = online
    # obj indx to detect
    self.tag_obj = None;  
    # number of objs          
    self.num_obj = 9;   
    # exploration method
    #   method 1: random sampling
    #   method 2: expected entropy 
    #   method 3: expected confusion reduction              
    self.method = method;        
    # class index           
    self.cls = range(1,self.num_obj+1) 
    # Stop condition: if MAP is larger or than this parameter, active touch stops
    self.stop_thr = {'max':0.9,'min':0.1}   
    # Initialize training data
    self.X_train, self.T_train = self.trainDataLoading()
    self.CLF = self.buildClassifier()
    # Initialize probabilistic confusion matrix
    self.CM = self.confusionMatrix()
    # evaluation metric (either rej_step or recog_step)
    self.metric = None
    
    ### dynamic data for exploration process###
    self.priors = np.ones(self.num_obj)/self.num_obj
    self.entpy  = stats.entropy(self.priors)
    # counts the actions taken 
    self.act_counts = np.ones(3) 
    self.obj_MAP = 0.5 # MAP value
    self.obj_MAP_idx = [] # MAP object index
    # counts the total exploration steps
    self.exp_steps = 0
    # trace the selected actions
    self.act_trace = []
    # trace the object priors
    self.pr_trace = [self.priors]

    self.printInit()

  def printInit(self):
    print "_________________________________________"
    print "activeExplorer::init:: Initialization finished!"
    print "Object Index"
    print self.cls
    #print "Confusion Matrix"
    #print self.CM[0]
    #print "   "
    #print self.CM[1]
    #print "   "
    #print self.CM[2]
    #print "_________________________________________"  
    
  def clearDynamicParameter(self):
    ## clear the parameters for exploration again
    ##
    self.priors = np.ones(self.num_obj)/self.num_obj
    self.entpy  = stats.entropy(self.priors)
    # counts the actions taken 
    self.act_counts = np.ones(3) 
    self.obj_MAP = 0.5 # MAP value
    self.obj_MAP_idx = [] # MAP object index
    # counts the total exploration steps
    self.exp_steps = 0
    # trace the selected actions
    self.act_trace = []
    # trace the object priors
    self.pr_trace = list(self.priors)
    #print "activeExplorer::clearDynamicParameter:: Dynamic parameter cleared up!"

  def trainDataLoading(self):
    ## build training data
    ## return X,y, each row represent data from an action
    ##   
    # ACTION 1: pressing for stiffness
    # load stiffness 
    load_stf = np.loadtxt(self.prior_path+"\X_stf.txt")
    T1 = np.loadtxt(self.prior_path+"\T_stf.txt")
    X1 = np.reshape(load_stf,(load_stf.shape[0],1))

    # ACTION 2: sliding for textures
    # load texture
    T2 = np.loadtxt(self.prior_path+"\T_tex(2d).txt")
    X2 = np.loadtxt(self.prior_path+"\X_tex(2d).txt")

    # ACTION 3: measuring center of mass
    # load center of mass
    T3 = np.loadtxt(self.prior_path+"\T_temp(10d).txt")
    X3 = np.loadtxt(self.prior_path+"\X_temp(10d).txt")

    X_train = [X1, X2, X3]
    T_train = [T1, T2, T3]

    return X_train,T_train

  def buildClassifier(self):
    ## build clf for each actions
    ## return CLF
    ##
    kernel = 1 * RBF([1.0])
    CLF = []
    for act_idx in range(3):
      clf = GaussianProcessClassifier(kernel=kernel).fit(self.X_train[act_idx], self.T_train[act_idx])
      CLF.append(clf)

    return CLF

  def confusionMatrix(self):
    # build the confusion probability matrix based on the classification results  
    num_obj = self.num_obj
    CM = []
    for act_idx in range(3):
      prob = self.CLF[act_idx].predict_proba(self.X_train[act_idx])
      cm = [[]]*num_obj
      for i in range(num_obj):
        idx = np.where(self.T_train[act_idx] == self.cls[i])[0]
        cm[i] = np.mean(prob[idx,:],axis=0)

      cm = np.array(cm)
      #np.savetxt('cm'+str(act_idx)+'.txt',cm)
      CM.append(cm)

    return CM

  def obsGenerator(self, nxt_class=None,nxt_act=None):
    ## Generating observation
    ##
    T_train = self.T_train
    X_train = self.X_train
    T_act = T_train[nxt_act]
    X_act = X_train[nxt_act]
    idx = np.where(T_act == nxt_class)[0]
    
    # adding gaussian noises with same data scale
    if nxt_act == 1 or nxt_act == 2: # sliding and static contact
      x = X_act[idx,:]
      noise_var = np.diag(np.std(X_act,axis=0))
      noise_mean = np.zeros(X_act.shape[1])
      rand_idx = np.random.choice(idx)
      obs = X_act[rand_idx,:]+ 0.0001*np.random.multivariate_normal(noise_mean,noise_var)
    else:
      #x = X_act[idx,:].ravel()
      x = X_act[idx,0]
      obs = [np.random.choice(x) + 0.01*np.random.normal(loc=0,scale=np.std(x))]

    if self.debug: print "DEBUG::obsGenerator::next_act = ",nxt_act," obs = ",obs

    return obs

  def bayesianUpdate(self,obs,nxt_act):
    if nxt_act == 1 or nxt_act == 2: # reshape sliding and static contact obs
      obs = np.array(obs).reshape(1, -1)
    else: # reshape pressing
      obs = np.array(obs).reshape(-1, 1)

    if self.debug: print "DEBUG::bayesianUpdate::obs = ",obs

    posterior = self.CLF[nxt_act].predict_proba(obs)
    # update priors
    pr = posterior*self.priors/np.sum(posterior*self.priors)
    pr_modified = pr.ravel() 
    pr_modified[pr_modified<0.01] = 0.01
    self.priors = pr_modified
    
    # update entropy 
    self.entpy = stats.entropy(self.priors)

    # MAP
    self.obj_MAP = self.priors.max()
    self.obj_MAP_idx = self.cls[self.priors.argmax()]

  def actionSelection(self):
    ##
    num_obj = self.num_obj
    method = self.method
    
    # Random Sampling
    if method == 1:
      nxt_act=np.random.randint(0,3)

    # Expected Entropy Reduction
    if method == 2:
      EXP_ENTPY = [] # Expected entropy for three actions
      for act in range(3):
        x = self.X_train[act]
        t = self.T_train[act] 
        clf = self.CLF[act]
        po = clf.predict_proba(x) # each row represents prob for an observation
        pr_ = matlab.repmat(self.priors, po.shape[0], 1)
        # bayesian update for all expected observation
        marg = np.array([np.sum(po*pr_,axis=1)])
        pr_ = (po*pr_)/matlab.repmat(marg.transpose(),1,po.shape[1])
        
        # the training data is skewed due to self.priors
        exp_entpy = 0 # expected entropy for an action
        for j in range(num_obj):
          pr_obj = pr_[np.where(t == self.cls[j])[0],:]
          ave_entpy_obj = np.mean(stats.entropy(pr_obj.transpose()))
          exp_entpy += self.priors[j]*ave_entpy_obj
        
        EXP_ENTPY.append(exp_entpy)

      #print "activeExplorer::actionSelection::EXP_ENTPY = %r" %EXP_ENTPY
      nxt_act = np.array(EXP_ENTPY).argmin()

    # Confusion Matrix method
    if method == 3:    
      UNT = np.zeros(3) # uncertainty for an action 
      for act in range(3):
        # predicted uncertainty
        cm = self.CM[act]
        count= self.act_counts[act]

        u = 0
        for i in range(self.num_obj):
          # expected uncertainty 0:low, 1:high
          u += np.power(cm[i,i]*self.priors[i],2)/np.sum(cm[i,:]*self.priors);

        UNT[act] = 1-u

      # calculate expected benefits
      BENF = 1-np.power(UNT,np.true_divide(1,self.act_counts))
      #print "activeExplorer::actionSelection::BENF = %r" %BENF

      # choose the action which results in larger percieved benefit
      nxt_act = BENF.argmax()

    return nxt_act

  def activeTouch(self,obs_obj=None):
      ## actively select actions to interact with the object for recognition purpose
      ##
      self.tag_obj = obs_obj
      # Start active exploration
      while self.obj_MAP<self.stop_thr['max'] and self.obj_MAP>self.stop_thr['min'] and self.exp_steps<=6:
        self.exp_steps += 1
        # actively select an action
        nxt_act = self.actionSelection()
        self.act_trace.append(nxt_act)
        self.act_counts[nxt_act] += 1

        if self.debug: print "DEBUG::activeExplorer::activeTouch::nxt_act = %r" %nxt_act

        # execuate action and get new data
        #   if online, then execuate actions and recieve observations
        if self.online:
          obs = self.onlineActionExecution(nxt_act)

        #   otherwise generate synthetic data
        else:
          obs = self.obsGenerator(obs_obj,nxt_act)

        # update priors, get MAP and entropy
        self.bayesianUpdate(obs,nxt_act)
        self.pr_trace.append(self.priors)

        if self.debug: print "DEBUG::activeExplorer::activeTouch::priors = %r" %self.priors
      
      self.printResults()

  def evalActiveTouch(self,trails=30, metric='recog_steps'):
    ## Evaluating active touch algorithm performance
    ## Metrics "recog_rate": average recogntion steps + misclassification rate
    ##            "In order to recognize objects (MAP>90%), how many steps are needed
    ## Metrics "rej_steps": average rejection steps + misclassification rate
    ##            "How many steps are needed to conclude that the explored object is not the one searched for"
    ##
    ## trails: number of trails repeated
    ##
    self.metric = metric

    TAR_OBJ = self.cls
    METHOD = [1,3]
    #RECOG_STEPS_MEAN = [[]]*3 # each idx represent method 1,2,3
    #RECOG_STEPS_VAR = [[]]*3
    #REJ_STEPS_MEAN = [[]]*3
    #REJ_STEPS_VAR = [[]]*3
    #RECOG_ERROR_RATE = [[]]*2
    #REJ_ERROR_RATE = [[]]*2

    if metric == 'recog_steps':
      print "EVALUATION RECOGNITION STEPS"
      for method in METHOD:
        self.method = method
        print "evalActiveTouch::method %r" %method
        
        error_rate = 0
        prior_trace = []
        #obj_recog_step_mean = []
        #obj_recog_step_var = []
        for tag_obj in TAR_OBJ:
          print "evalActiveTouch::tag_obj %r" %tag_obj
          
          reg_step = []
          for _ in range(trails):
            self.clearDynamicParameter()
            # touching the target object
            self.activeTouch(tag_obj)

            prior_trace.append(self.obj_MAP)
            if self.obj_MAP_idx!=tag_obj:
              error_rate+=1 
            #reg_step.append(self.exp_steps)

        prior_trace = np.array(prior_trace)
        print "_________________________________________"
        #print "prior_trace mean = ",np.mean(prior_trace),"variance = ",np.std(prior_trace)
        print 'error rate = ', error_rate/float(self.num_obj*trails)
        print "_________________________________________"   

  def printResults(self):
    ## print the exploration results for one object
    print "_________________________________________"
    print "activeExplorer::activeTouch finished!"
    print "obj_MAP = %r" %self.obj_MAP
    print "obj_MAP_idx = %r" %self.obj_MAP_idx
    print "tg_obj = %r" %self.tag_obj
    print "exploration step = %r" %self.exp_steps
    print "action trace %r" %self.act_trace
    print "priors trace"
    print self.pr_trace
    print "_________________________________________" 

  def plotEvalResults(self):
    ## plot the evaluation results (recognition steps + rejection steps)
    print "activeExplorer::plotEvalResults::plot the evaluation results"
    
    num_obj = self.num_obj

    if self.metric == 'recog_steps':
      steps_mean = np.loadtxt("eval_results\AE_RECOG_STEPS_MEAN.txt")
      steps_var = np.loadtxt("eval_results\AE_RECOG_STEPS_VAR.txt")
      error_rate = np.loadtxt("eval_results\AE_RECOG_ERROR_RATE.txt")    
    elif self.metric == 'rej_steps':
      steps_mean = np.loadtxt("eval_results\AE_REJ_STEPS_MEAN.txt")
      steps_var = np.loadtxt("eval_results\AE_REJ_STEPS_VAR.txt")
      error_rate = np.loadtxt("eval_results\AE_REJ_ERROR_RATE.txt")  

    plt.figure()

    c = ['b','r','g']
    method = ['random','expected entropy','confusion reduction']
    for act in range(3):
      plt.subplot(1,3,act+1)
      x = range(1,num_obj+1,1)
      y = steps_mean[act]
      err = steps_var[act]
      plt.bar(x, y, width = 0.5, yerr=[(np.zeros(num_obj)), (err)], color=c[act])
      plt.ylim(1,7)
      plt.xlabel('object index')
      plt.ylabel('average'+self.metric)
      plt.title(str(method[act]),fontsize = 20)

    plt.show()

  def onlineGetObservation(self, nxt_act):
    # return obs
    return NotImplemented 

  def onlineActionExecution(self, nxt_act):
    # obs = self.onlineGetObservation(nxt_act)
    # return obs
    return NotImplemented

if __name__ == '__main__':
  path = "syn_data"
  aE = activeExplorer(method=3,prior_path=path,debug=False)
  tag_obj = range(1,10)
  for tg in tag_obj:
    aE.clearDynamicParameter()
    aE.activeTouch(tg)








