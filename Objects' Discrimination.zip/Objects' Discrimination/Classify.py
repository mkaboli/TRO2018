import numpy as np
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.decomposition import PCA
import mpl_toolkits.mplot3d
import matplotlib.cm as cm
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.gaussian_process.kernels import RBF
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score
np.set_printoptions(linewidth=10000000)

#====================================================================
        # Created by Mohsen Kaboli, mohsen.kaboli@tum.de, 2016
 #====================================================================





class Classifier(object):
    def __init__(self, obj_idx=range(1, 121), sample_nr=100, name='three_axis'):
        """

        Args:
            obj_idx: a list of objects to be classified
            sample_nr: number of samples for each object
            name: name of the target files
        """
        self.obj_idx_selected = obj_idx
        self.num_obj = len(obj_idx)
        print('number of objects to classify: {}'.format(self.num_obj))
        self.sample_nr = sample_nr

        # loading data
        data_whole = np.loadtxt("./syn_dataset/X_obs_" + name + ".txt")
        y_whole = np.loadtxt("./syn_dataset/y_target_" + name + ".txt")

        # data extraction
        self.data, self.target = self.data_extraction(data_whole, y_whole)

        std_scale = preprocessing.StandardScaler().fit(self.data)
        # std_scale = preprocessing.MinMaxScaler().fit(self.data)
        # print("mean:{}".format(std_scale.mean_))
        # print("std:{}".format(np.sqrt(std_scale.var_)))
        self.data_std = std_scale.transform(self.data)

        self.data2d, self.d2 = self.dim_reduction(2)
        self.data3d, self.d3 = self.dim_reduction(3)

        self.part_data, self.part_target = self.take_some_data(self.data3d, self.target, n_sample=100)

    def data_extraction(self, data_whole, y_whole):
        """

        Args:
            data_whole: observation matrix with complete data
            y_whole: target matrix with all label

        Returns:
            the function takes the selected idx label out of the given complete data
            and return the observations/targets as two arrays
        """
        dim = data_whole.shape[1]
        data = np.empty([0, dim])
        target = []
        for i in range(self.num_obj):
            t = np.where(y_whole == self.obj_idx_selected[i])[0]
            data = np.append(data, data_whole[t, :], axis=0)
            target = target + [self.obj_idx_selected[i]] * self.sample_nr
        target = np.array(target).reshape((-1, 1))

        return data, target

    def dim_reduction(self, n_com):
        pca = PCA(n_components=n_com).fit(self.data_std)
        reduced_data = pca.transform(self.data_std)
        d = sum(pca.explained_variance_ratio_)

        return reduced_data, d

    def viz_2d(self, number_switch=False):

        """

        Args:
            number_switch: if on, each sample will be annotated with number

        Returns:
            visualize the samples in 2D

        """

        cl = cm.rainbow(np.linspace(0, 1, self.num_obj))
        plt.figure()
        for i in range(0, self.num_obj):
            plt.scatter(self.data2d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 0],
                        self.data2d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 1],
                        marker='o', s=100, c=cl[i], label='obj'
                        + str(self.obj_idx_selected[i]))
            if number_switch:
                n = range(self.sample_nr)
                xx = self.data2d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 0]
                yy = self.data2d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 1]
                for j, txt in enumerate(n):
                    plt.annotate(txt, (xx[j], yy[j]))

        plt.legend(loc='upper right')
        plt.xlim([-7, 7])
        plt.ylim([-5, 6])
        plt.title("2D_var=" + str(round(self.d2, 2)), fontsize=15, loc='right')
        plt.show()

    def viz_3d(self, number_switch=False):

        cl = cm.rainbow(np.linspace(0, 1, self.num_obj))
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        ax.view_init(45, 35)
        for i in range(0, self.num_obj):
            ax.scatter(self.data3d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 0],
                       self.data3d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 1],
                       self.data3d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 2],
                       marker='o', s=100, c=cl[i], label='obj' + str(self.obj_idx_selected[i]))

            if number_switch:
                n = range(self.sample_nr)
                xx = self.data3d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 0]
                yy = self.data3d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 1]
                zz = self.data3d[i * self.sample_nr:i * self.sample_nr + self.sample_nr, 2]
                for j, txt in enumerate(n):
                    ax.text(xx[j], yy[j], zz[j], '%s' % (str(txt)))
        plt.legend(loc='upper right')

        plt.title("3D_var=" + str(round(self.d3, 2)), fontsize=15, loc='right')
        plt.show()
        # plt.savefig('nihao.pdf', dpi=1200)

    def take_some_data(self, obs_whole, tar_whole, n_sample=50):
        """

        Args:
            obs_whole: observation matrix
            tar_whole: target matrix,
            n_sample: number of samples to keep

        Returns:
            obs and target with given number of samples

        """
        dim = obs_whole.shape[1]
        data = np.empty([0, dim])
        target = []
        n_choice = np.random.choice(self.sample_nr, n_sample)
        for i in range(self.num_obj):
            t = np.where(tar_whole == self.obj_idx_selected[i])[0]
            t = t[n_choice]
            data = np.append(data, obs_whole[t, :], axis=0)
            target = target + [self.obj_idx_selected[i]] * n_sample
        # target = np.array(target).reshape((-1, 1))
        print('dimension of data: {}'.format(data.shape[1]))
        print('number of samples: {}'.format(n_sample))

        return data, target

    def classifier_gpc(self):
        """Gaussian Process Classifier
        Returns:
            mean/std of the classification performance
        Note: the multi-threads function is on to speed up, see n_jobs

        """
        k = 1.0 * RBF([1.0])
        # data = [self.data] + [self.data_std] + [self.data2d] + [self.data3d]
        # target = [self.target] * len(data)
        # score = []
        # for d, t in zip(data, target):
        #     clsf = GaussianProcessClassifier(kernel=k, n_jobs=-1)
        #     scores = cross_val_score(clsf, d, t, cv=5)
        #     score.append(scores.mean())
        clsf = GaussianProcessClassifier(kernel=k, n_jobs=-1)
        scores = cross_val_score(clsf, self.part_data, self.part_target, cv=5)
        score_mean = scores.mean()
        score_std = scores.std()
        return score_mean, score_std

    def classifier_svm(self):
        clsf = SVC(kernel='rbf', decision_function_shape='ovr')
        scores = cross_val_score(clsf, self.part_data, self.part_target, cv=10, n_jobs=-1)
        score_mean = scores.mean()
        score_std = scores.std()
        return score_mean, score_std


if __name__ == "__main__":
    # acc_mean = []
    # acc_std = []
    # for _ in range(10):
    # idx = np.random.choice(np.arange(1, 41), 10).tolist() + \
    #       np.random.choice(np.arange(41, 81), 10).tolist() +\
    #       np.random.choice(np.arange(81, 121), 10).tolist()

    idx = range(1, 121)
    clf = Classifier(obj_idx=idx)
    # clf.viz_3d()
    # clf.viz_3d()
    # print(clf.classifier_gpc())
    x = clf.classifier_svm()
    # acc_mean.append(x[0])
    # acc_std.append(x[1])
    print('Mean accuracy: {}'.format(x[0]))
    print('standard deviation: {}'.format(x[1]))
    # np.savetxt('svm_mean.txt', acc_mean)
    # np.savetxt('svm_std.txt', acc_std)
