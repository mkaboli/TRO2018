import numpy as np
import random
from scipy.ndimage.interpolation import shift

SampleNum = 1000 # length of data list 
SampleNumTemp = 10000 # length of data list for temperature (around 158s)
NUM_PROX_GRID = 9 # number of girds for training proximity observation
PROX_H = [0.05,0.04,0.03,0.02,0.015,0.01,0.008,0.005,0.002]
#==================================================================================
#   Mohsen Kaboli , Technical University of Munich
#   mohsen.kaboli@tum.de
#   @2016
#==================================================================================
# sensorModel Class
# define the sensor setup here (skincell patch), including:
# observation model for proximity sensing
# fetch the proximity observations and tactile observations
#==================================================================================

class sensorModel:

    def __init__(self, num=7):
        ## num: number of cells in a patch
        ##
        self.cell_num=num
        self.cell_pos, self.prox, self.force, self.prox_mu, self.prox_sig, \
        self.prox_bk=self.sensor_init()

        # for object recognition:        
        self.force_sequence = [np.zeros(7)]*SampleNum
        self.accx_sequence = [np.zeros(7)]*SampleNum 
        self.accy_sequence = [np.zeros(7)]*SampleNum
        self.accz_sequence = [np.zeros(7)]*SampleNum
        self.temp_sequence = [np.zeros(7)]*SampleNumTemp

        self.ForceSequence=None
        self.AccXSequence =None
        self.AccYSequence =None
        self.AccZSequence =None
        self.TempSequence = None

        self.avgForce=None
        self.tactile_descriptor=None
        self.actx=None

    def sensor_init(self):
        # cell(proximity sensor) relative position w.r.t centroid, idx corresponds to sensor idx 
        cell_pos1=[0.0,-0.0279475100673, 0.0]
        cell_pos2=[0.0239781893439,-0.0140281220431, 0.0]
        cell_pos3=[-0.024007829571,-0.0139827480145, 0.0]
        cell_pos4=[0.0, 0.0, 0.0]
        cell_pos5=[-0.0239429173257, 0.014060894093, 0.0]
        cell_pos6=[0.0239316117869, 0.0140372336558, 0.0]
        cell_pos7=[0.0, 0.0279475100673, 0.0]

        cell_pos=[cell_pos1, cell_pos2, cell_pos3, cell_pos4, cell_pos5, cell_pos6, cell_pos7]
        
        # sensor data, stored as vector (assign manually) 
        prox=0.002*np.ones((self.cell_num))  
        force=1/3.*np.ones((self.cell_num))
        '''
        # proximity model (gaussian distribution learned from the training dataset, distance from 20cm to 0cm)
        prox_mu=np.array([0.0010, 0.0011, 0.0012, 0.0014, 0.0015, 0.0017, 0.0018, 0.0021, \
                            0.0024, 0.0027, 0.0032, 0.0039, 0.0047, 0.0060, 0.0081, 0.0114, \
                            0.0176, 0.0308, 0.0676, 0.2466, 0.8213])
        prox_sig=np.array([0.0004, 0.0004, 0.0004, 0.0004, 0.0004, 0.0004, 0.0004, 0.0005, \
                           0.0005, 0.0005, 0.0005, 0.0006, 0.0006, 0.0008, 0.0009, 0.0013, \
                           0.0020, 0.0035, 0.0082, 0.0364, 0.0241])
        '''
        
        # new proximity model: 5,4,3,2,1.5,1,0.8,0.5,0.2cm, see macro PROX_H
        prox_mu = np.loadtxt('training_data/proximity_sensor/proximity_m.txt')
        prox_sig = np.loadtxt('training_data/proximity_sensor/proximity_v.txt')
        prox_mu = prox_mu[::-1]
        prox_sig = prox_sig[::-1]
        
        
        # belief of proximity P(prox|dist)
        prox_bk=np.ones((self.cell_num, NUM_PROX_GRID))
        
        return cell_pos, prox, force, prox_mu, prox_sig, prox_bk
    
    def obs_prox(self,prox):
        '''
        calculate the proximity observation based on gaussian distribution
        return is the height estimate, height is defined by the macro PROX_H
        '''
        prox_bk=np.ones((self.cell_num, NUM_PROX_GRID))
        
        for i in range(self.cell_num):
            prox_bk[i, :]=1/(np.sqrt(2*np.pi)*self.prox_sig)*\
                        np.exp(-np.power(self.prox_mu-self.prox[i], 2)/(2*np.power(self.prox_sig, 2)))

        return prox_bk

    def getHeightMAP(self):
        '''
        return the most probable height (in meter)
        comparing the idx among all cells, return the 'smallest' distance estimate 
        '''
        prob_prox = self.getProxBk()
        height_idx = []
        for i in range(self.cell_num):
            value=prob_prox[i,:]
            max_idx = value.argmax()
            height_idx.append(max_idx)

        # return the s
        max_idx = np.array(height_idx).max()
        max_value = PROX_H[max_idx]

        return max_value
    
    def setPos(self, data):
        ## update skincell patch position (a list from idx1~idx7)
        self.cell_pos=data
    
    def setProx(self, data):
        ## update Proximity 
        self.prox=np.array(data)
        self.prox_bk=self.obs_prox(np.array(data))
    
    def setForce(self, data):
        ## update Force
        self.force=np.array(data)

    def getForce(self): 
        ## get the force
        return self.force
    
    def getProx(self):
        ## get the proximity
        return self.prox

    def getProxBk(self):
        ## get the proximity belief
        return self.prox_bk

    def getTotalForce(self):
        return self.force.sum()

    def getAveTotalForce(self):
        return (1/float(self.cell_num*3))*self.force.sum()

    def getSlidingFeature(self):
        ## calculate the robust tactile descriptor from the accelormeter data
        ##
        timestep=1
    
        acc_x_seq=np.array(self.AccXSequence)
        acc_y_seq=np.array(self.AccYSequence)
        acc_z_seq=np.array(self.AccZSequence)
        
        act_x_seq=[]
        act_y_seq=[]
        act_z_seq=[]

        mob_x_seq=[]
        mob_y_seq=[]
        mob_z_seq=[]

        comp_x_seq=[]
        comp_y_seq=[]
        comp_z_seq=[]

        for i in range(self.cell_num):
            acc_x=acc_x_seq[:,i]
            acc_x_shift=shift(acc_x,-1,cval=0)

            v_x=(1/timestep)*(acc_x_shift-acc_x)
            v_x=np.delete(v_x,-1)
            v_x_shift=shift(v_x,-1,)
            
            a_x=(1/timestep)*(v_x_shift-v_x)
            a_x=np.delete(a_x,-1)

            act_x=np.var(acc_x) # activity in x direction
            mob_x=np.sqrt(np.var(v_x)/act_x) # mobility in x direction
            comp_x=np.sqrt(np.var(a_x)/np.var(v_x))/mob_x # complexity in x direction

            act_x_seq.append(act_x)
            mob_x_seq.append(mob_x)
            comp_x_seq.append(comp_x)

        act_x_seq=np.array(act_x_seq)
        mob_x_seq=np.array(mob_x_seq)
        comp_x_seq=np.array(comp_x_seq)

        for i in range(self.cell_num):
            acc_y=acc_y_seq[:,i]
            acc_y_shift=shift(acc_y,-1,cval=0)

            v_y=(1/timestep)*(acc_y_shift-acc_y)
            v_y=np.delete(v_y,-1)
            v_y_shift=shift(v_y,-1,)
            
            a_y=(1/timestep)*(v_y_shift-v_y)
            a_y=np.delete(a_y,-1)

            act_y=np.var(acc_y) # activity in y direction
            mob_y=np.sqrt(np.var(v_y)/act_y) # mobility in y direction
            comp_y=np.sqrt(np.var(a_y)/np.var(v_y))/mob_y # complexity in y direction
            
            act_y_seq.append(act_y)
            mob_y_seq.append(mob_y)
            comp_y_seq.append(comp_y)


        act_y_seq=np.array(act_y_seq)
        mob_y_seq=np.array(mob_y_seq)
        comp_y_seq=np.array(comp_y_seq)
        
        for i in range(self.cell_num):
            acc_z=acc_z_seq[:,i]
            acc_z_shift=shift(acc_z,-1,cval=0)

            v_z=(1/timestep)*(acc_z_shift-acc_z)
            v_z=np.delete(v_z,-1)
            v_z_shift=shift(v_z,-1,)
            
            a_z=(1/timestep)*(v_z_shift-v_z)
            a_z=np.delete(a_z,-1)

            act_z=np.var(acc_z) # activity in z direction
            mob_z=np.sqrt(np.var(v_z)/act_z) # mobility in z direction
            comp_z=np.sqrt(np.var(a_z)/np.var(v_z))/mob_z # complexity in z direction


            act_z_seq.append(act_z)
            mob_z_seq.append(mob_z)
            comp_z_seq.append(comp_z)
        
        act_z_seq=np.array(act_z_seq)
        mob_z_seq=np.array(mob_z_seq)
        comp_z_seq=np.array(comp_z_seq)

        tactile_descriptor={'activity':[act_x_seq.mean(),act_y_seq.mean(),act_z_seq.mean()],\
                            'mobility':[mob_x_seq.mean(),mob_y_seq.mean(),mob_z_seq.mean()],\
                            'complexity':[comp_x_seq.mean(),comp_y_seq.mean(),comp_z_seq.mean()]}

        self.tactile_descriptor=tactile_descriptor
        self.actx=act_x_seq.mean()




