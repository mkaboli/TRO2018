Search is implemented in ROS 
details see class Agent