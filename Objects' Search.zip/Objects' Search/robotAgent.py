#!/usr/bin/env python

import time, sys, threading, math
import copy
import datetime
import socket, select
import struct
import traceback, code
import optparse
import SocketServer
import rospy
import numpy as np
import random
import matplotlib
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import matplotlib.pyplot as plt
from std_msgs.msg import String
from std_msgs.msg import Float32
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import Pose
from mpl_toolkits.mplot3d import Axes3D
from geometry_msgs.msg import WrenchStamped, Point
from sensor_msgs.msg import JointState
import matplotlib.cm as cm

import sensorModel
import workspace3D

#==================================================================================
# Author: Mohsen Kaboli 
# mohsen.kaboli.tum.de
# @2016
#==================================================================================

# This file contains the class Agent, which has the following main modules:
#
# init: connect to the UR10 and sensors (skin patch, 7 cells)
# Module Active Localization and Mapping
#           the robot actively explores the working-space and localize the objects
#
# Module Visualization
#           plots for localization and discrimination task
#
# Module Perception
#           ROS subscriber and publisher with skin path sensors
#
# Module Action
#           Control UR 10 
#
# the workspace exploration + object discrimination can either be executed online,
# or with simulated training database
# 
#==================================================================================

HOST="192.168.1.10"  # The remote host for UR10
PORT=30002  # The port to send the command to the robot
REVERSE_PORT=50001 # The port to recieve the information from the robot 
PC_ADDRESS = "192.168.1.3"
R_XYZ=[2.2208,-2.2208,0.0000]  # end-effector rotation (rad) defined manually

class Agent:
  def __init__(self, ws, sensor, obj_processor, connection=False):
    '''
    Input: 

    ws: (class) the working environment the robot will explore
    sensor: (class) sensor data
    obj_processor: object processor, containing objectlist and active touch strategy 
    connection: connect to the real robot (True), by default False
                when not connect to the real robot, program will run simulation
    '''
    print "============ Robot agent initializing ============"
    print " Agent::_init_::Connection to real robot is ", connection
    
    # -------------------- Define robot-state, action parameters, environment --------------------
    #
    # End-effector global coordinate w.r.t base
    self.r_xyz = R_XYZ
    self.current_grid_pos = ws.init_pos  # robot current grid (in 3D, for open-loop control)
    self.cbEF = [0.00]*3 # [Current Position of End Effector] (for closed-loop control)
    self.cbJS = [0.00]*6 # [Current Position in Joint Space] (for closed-loop control)
    
    # Environment, sensors and object
    self.ws=ws
    self.ss=sensor
    self.obj=obj_processor
    
    # for visualization purpose only
    self.ax1=None
    self.ax2=None
    self.goal_trace=[]
    
    # action states and action selection policy
    self.actions, self.action_length=self.action_initilization()
    self.dist=0

    # for exploration algorithm evaluation only
    self.entropy_trace=[]
    self.ig_trace=[]

    # -------------------- Subscriber: connect skincell patch and robot output  --------------------
    if connection:
      rospy.Subscriber("/force_topic",Float32MultiArray, self.force_callback, queue_size=1 ) # force signal
      rospy.Subscriber("/accx_topic", Float32MultiArray, self.accx_callback, queue_size=10) # accx
      rospy.Subscriber("/accy_topic", Float32MultiArray, self.accy_callback, queue_size=10) # accy
      rospy.Subscriber("/accz_topic", Float32MultiArray, self.accz_callback, queue_size=10) # accz
      rospy.Subscriber("/temp_topic",Float32MultiArray, self.temp_callback, queue_size=10) # temperature signal

      rospy.Subscriber("joint_states", JointState, self.joint_states_callback)
      rospy.Subscriber('end_effector', Point, self.end_effector_callback)
    
    # to evaluate active search (localization) algorithm offline
    if not connection:
      self.proximity_database = np.loadtxt('training_data/eval_search_offline/proximity_output.txt')
      self.world_position = np.loadtxt('training_data/eval_search_offline/ws_pos.txt')
    # -------------------- UR Robot initialization --------------------
    self.connection = connection
    if connection:
      # connect to UR robot
      print 'Agent::init::connecting to UR server...'

      with open('/home/feng/catkin_ws/src/projActiveExploration/universal_robot/ur_driver/src/operation_control_program') as ctrl: CONTROL_PROGRAM = ctrl.read()
      self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      self.s.connect((HOST,PORT))
      self.s.sendall(CONTROL_PROGRAM)

      self.serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      self.serversocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
      # move to initial position
      #self.move_robot_home_init()
      #touch_pos = [0.75,0.05,0]
      #self.move_touching_init(touch_pos)
      self.move_localization_init()

  #-----------------------------------------------------------------------------------------
  # Modual Active Localization and Mapping
  # mapping the objects' locations in an unstructured environment thourgh proximity sensors.
  # methodology: entropy, simple search and random search
  #-----------------------------------------------------------------------------------------  
  def action_initilization(self):
    '''
    9 actions: Right, Right-Up, Up, Left-Up, Left, Left-Down, Down-Left, Down, Right-Down and Stay
    grid_size[0] grid num for length, grid_size[1] grid num for width
    '''
    intvl_l = self.ws.length / float((self.ws.grid_size[0] - 1))
    intvl_w = self.ws.width / float((self.ws.grid_size[1] - 1))
    side_dist = np.sqrt(np.power(intvl_w,2)+np.power(intvl_l,2))      
    
    actions = {'right':[0, intvl_l], 'rightup':[-intvl_w, intvl_l], 'up':[-intvl_w, 0], 'leftup':[-intvl_w, -intvl_l], \
                         'left':[0, -intvl_l], 'leftdown':[intvl_w, -intvl_l], 'down':[-intvl_w,0], 'rightdown':[intvl_w, intvl_l], \
                         'stay':[0, 0]}

    action_length = {'right':intvl_l, 'rightup':side_dist, 'up':intvl_w, 'leftup':side_dist, \
                         'left':intvl_l, 'leftdown':side_dist, 'down':intvl_w, 'rightdown':side_dist, \
                         'stay':0}

    return actions,action_length

  def forward_state(self):
    '''
    return valid forward state and the name of actions (2D)
    '''
    keys=self.actions.keys()
    random.shuffle(keys) 
    key_trace=[]
    fs=[]  # available forward state in the working space
    for key in keys:
      x=np.array(self.actions[key])
      y=np.array(self.current_grid_pos[0:2])
      forward_state_all=list(x+y)
      # check bound
      bound_check=forward_state_all[0]>=self.ws.init_pos[0] \
      and forward_state_all[0]<=self.ws.init_pos[0]+self.ws.width \
      and forward_state_all[1]>=self.ws.init_pos[1] \
      and forward_state_all[1]<=self.ws.init_pos[1]+self.ws.length
      
      if bound_check:
        fs.append(forward_state_all)
        key_trace.append(key)  

    return fs, key_trace 

  def simple_search_observation(self, cs):
    '''
    # simulate non-detection observation model
    '''
    Pdmax=0.9;
    dmax=0.06;
    sigma=0.6;
    diff=np.array([i[0:2]-cs[0:2] for i in self.ws.grid2D])
    dist=np.array([np.sqrt(np.dot(j, j)) for j in diff])
    occ=np.array(Pdmax*np.exp(-sigma*np.square(dist/dmax))) 

    return occ

  def proximity_generator(self):
    '''
    for offline evaluation only
    '''
    # find the idx of the robot's current position
    distance= np.linalg.norm(self.world_position-self.current_grid_pos[0:2],axis=1) 
    pos = distance.argmin()

    prox_value = self.proximity_database[pos,:]

    return prox_value

  def information_gain(self, sys_entropy=None, fs=None, method='search'):
    '''
    calculate 1-step look ahead information gain    
    input: system entropy, forward state, current grid posterior and exploration method
    output: list of information gain
    '''
    info_gain=[]
    for cs in fs:
      if (method is 'entropy') or (method is 'entropy_asy'): 
        occ_priors=self.ws.occ_bk.copy()

        # here we consider 3D grids 
        pos=list(cs)
        pos.append(self.ws.init_pos[2])

        exp_posterior=self.bayesian_predict(cs=pos, occ_bk=occ_priors.copy(), method='entropy')  # expected posterior

        if method is 'entropy':
          fent=self.grid_entropy(exp_posterior)  # expected entropy
        
        exp_info=sys_entropy-fent  #expected information gain

      if method is 'search':
        occ2D_priors=self.ws.occ2D_bk.copy()
        # here we consider 2D grids 
        exp_posterior=self.bayesian_predict(cs, method='search')  # expected posterior
        exp_info=1-np.dot(1-exp_posterior, occ2D_priors)  # expected information gain
     
      info_gain.append(exp_info) 
    
    return info_gain
  
  def obs_predict(self, cs, occ_bk):
    '''
    predict the occupancy based on sensor model (predicted_obs2.m)
    output is the expected occupancy grid
    idea: MAP heigth at cs update all its surroundings with this height in accordance with exponential distance function
    for one occ grid, its occ probability is the joint probability of 7 skincells. 
    '''
    obs_occ=0.5*np.ones((self.ws.grid_bk.shape[0]))
    grid3D=self.ws.grid.copy()
    grid_h=np.linspace(self.ws.height,0,num=self.ws.grid_size[2])

    sigma=np.matrix(((0.004,0,0),(0,0.004,0),(0,0,0.001)))
    
    # affected region
    x=0 # +-1 grid
    y=0 # +-1 grid
    
    # trace the position and their prob
    pos_trace=[]
    nd_prob_trace=[]

    # scan each cell
    for h in range(self.ss.cell_num):  
      pos=self.ss.cell_pos[h]
      disp_cell=np.array(cs)+np.array(pos)  # cell absolute position [x,y,z]
      distance=(grid3D[:, 0]-disp_cell[0])**2+(grid3D[:, 1]-disp_cell[1])**2     
      label=np.where(distance==distance.min())
      lab=label[0]
    
      obs=obs_occ[lab].copy()
      max_idx=obs.argmax()
      max_value=obs.max()
      max_h=self.ws.height-grid3D[max_idx,2]

      grid=grid3D[lab,0:2].copy()
      cell_center=grid[0]
      
      mu=np.array([cell_center[0],cell_center[1],max_h])

      # scan each affected region
      for i in np.arange(-x,x+1):
        for j in np.arange(-y,y+1):
          disp_x=cell_center[0]+i*self.ws.intvl_w
          disp_y=cell_center[1]+j*self.ws.intvl_l

        p=[]
        if len(lab)>0: # valid point 
          # scan each height
          for k in range(grid_h.size):      
            if k<max_idx:
              dk=np.array([disp_x,disp_y,grid_h[k]])-mu          
              prob=np.exp(-0.5 * np.matrix(dk) * sigma.I * np.matrix(dk).T) # probability of detected
              prob=np.squeeze(np.asarray(prob))

            else:
              prob=np.array(max_value)
            
            p.append(prob)

          p=np.array(p)

          if p.max()<0.5:
            p=0.45*np.ones((self.ws.grid_size[2]))

          # calculate joint probability for non-detection
          if [disp_x,disp_y] in pos_trace:
            idx=pos_trace.index([disp_x,disp_y])
            pre=nd_prob_trace[idx]
            nd_p=(1-p)*pre #nd_p: probablity of non-detected
            nd_prob_trace[idx]=nd_p

          else:
            pos_trace.append([disp_x,disp_y])
            nd_prob_trace.append(1-p)

    # final probability for detection
    prob_trace=[1-i for i in nd_prob_trace]

    for temp in prob_trace:
      idx=temp.argmax()
      val=temp.max()
      temp[idx:]=val # rounding

    # finally updated affected region 
    i=0
    for pos in pos_trace:
      distance=(grid3D[:, 0]-pos[0])**2+(grid3D[:, 1]-pos[1])**2     
      label=np.where(distance==distance.min())
      lab=label[0]
      obs_occ[lab]=prob_trace[i]
      i+=1
    
    return obs_occ

  def bayesian_predict(self, cs, occ_bk=None, method='search'):
    '''
    predict belief one-step look ahead (updateBayesPredicted.m)
    '''
    if method is 'entropy':
      obs_occ=self.obs_predict(cs, occ_bk)
      # normalization
      obs_empty=1-obs_occ
      occ=(obs_occ*occ_bk)/((obs_occ*occ_bk)+(obs_empty*(1-occ_bk)))

    # non-detection observation model
    if method is 'search':
      occ=self.simple_search_observation(cs)
    
    return occ
  
  def occ_update(self):
    '''
    occupance grid update, only for 3D occ
    '''
    obs_occ=0.5*np.ones((self.ws.grid_bk.shape[0]))
    occ_squeeze=self.ws.grid3D_MAP()  
    h_num=self.ws.grid_size[2]
    
    for k in range(occ_squeeze.shape[0]): # for every position
      priors=obs_occ[h_num*k:h_num*(k+1)]
      max_val=occ_squeeze[k,2]
      max_idx=occ_squeeze[k,4]

      for l in range(priors.shape[0]):
        if l>=max_idx:
          priors[l]=max_val
        else:
          priors[l]=1-max_val

      obs_occ[h_num*k:h_num*(k+1)]=priors

    return obs_occ

  def bayesian_update(self, cs, m, method='search'):
    '''
    update current belief in 3D grid and 2D grid(for for simple search) (updateBayesMeasurement.m)
    s: robot current state;    m: measurement;  
    update the current grid belief (grid_bk)
    '''
    grid_priors=self.ws.grid_bk.copy()
    grid_posterior=self.ws.grid_bk.copy()

    # get observation probability
    prox_bk=self.ss.obs_prox(m)
    
    # update the P(prox|dist) for related parts
    grid_xyz=self.ws.grid

    for j in range(self.ss.cell_num):  #scan each cell
      pos=self.ss.cell_pos[j]
      cell_cs=np.array(cs)+np.array(pos)  # cell absolute position [x,y,z]
      distance=(grid_xyz[:, 0]-cell_cs[0])**2+(grid_xyz[:, 1]-cell_cs[1])**2
      
      #assign prox_bk to the nearest grid           
      label=np.where(distance==distance.min())
      value1=label[0]

      # bayesian update
      value2=grid_priors[value1]*prox_bk[j]/float(np.dot(prox_bk[j],grid_priors[value1]))
      
      offset=np.round(self.ws.z_offset*100)+1# Here compensate the offset of the change of robot height (see workspace3D _init_)  
      for l in range(prox_bk.shape[1]):
        if l>offset:
          grid_posterior[value1[l]]=value2[l]
        else:
          grid_posterior[value1[l]]=0.01

    self.ws.grid_bk=grid_posterior

    ## simple search: 2D occ update
    if method is 'search': 
      occ2D_priors=self.ws.occ2D_bk
      obs=self.simple_search_observation(cs)
      posterior=(1-obs)   
      posterior_new=posterior*occ2D_priors  # Bayesian update
      posterior_new=posterior_new/posterior_new.sum()
        
      self.ws.occ2D_bk=posterior_new

    ## entropy: 3D occ update
    if method is 'entropy':
      occ_priors=self.ws.occ_bk.copy()
      obs_occ=self.occ_update()
      #print 'bayesian_update::obs_occ %r' %obs_occ[4000:4040]
    
      obs_empty=1-obs_occ
      occ=(obs_occ*occ_priors)/((obs_occ*occ_priors)+(obs_empty*(1-occ_priors)))
      self.ws.occ_bk=occ

  def grid_entropy(self,posterior):
    '''
    calculate total entropy for the working space (grid_entropy.m)
    ret: entropy 0~1
    '''
    # leave out data either 0 or 1
    posterior[np.abs(posterior)<0.01]=0.01  # some zeros
    posterior[np.abs(posterior-1)<0.01]=0.99  # some ones
    P=posterior.copy()

    entropy=-np.sum(P*np.log2(P)+(1-P)*np.log2(1-P))
    entropy=entropy/float(P.shape[0])

    return entropy

  def localization(self, step=100, method='search', sim=True, cout=True):
    '''
    Realizing active localization and mapping algorithm

    Input

    step: exploration step
    sim: simulate the control policy via 3D plot
    cout: print out step action, goal position and entropy
    method: 
        'entropy': 1 step look ahead information gain based from entropy
        'random': random exploraion strategy
        'search': non-detection simple search
        'uniform': uniform search to collect for training database 
    '''

    print "============ Active Localization and Mapping ============"
    # visualization initialization
    self.goal_trace.append(self.ws.init_pos[0:2])
    self.simulation_loc(init=True,sim=sim)

    # real robot initialization
    self.move_localization_init()

    ## ------ Exploration begins -------
    ##
    posterior = self.ws.grid_bk.copy()
    sys_entropy = self.grid_entropy(posterior)
    self.entropy_trace.append(sys_entropy)

    sentpy_ = sys_entropy
    current_step = 0

    if method is 'uniform':
      proximity_output = []

      grid2D = self.ws.grid2D.copy()
      step = grid2D.shape[0]

      for goal_pos in grid2D:
        current_step += 1
        print 'step ',current_step
        goal_pos = list(goal_pos)
        goal_pos.append(self.ws.init_pos[2])
        # robot manipulation
        if self.connection: self.moveTo(goal=goal_pos)
        # visualization update
        self.goal_trace.append(goal_pos[0:2])

        self.simulation_loc(goal_pos=goal_pos,sim=sim,current_step=current_step,step=step)

        # update robot current position
        self.current_grid_pos=goal_pos 

        # fetch the proximity data 
        if self.connection: 
          self.fetch_sensor_data_once()
        else: 
          m=self.proximity_generator() 
          self.ss.setProx(m)

        proximity_output.append(self.ss.prox)

        prox_new=self.ss.getProx()
        self.bayesian_update(goal_pos, prox_new, method=method)

        # update entropy 
        posterior=self.ws.grid_bk.copy()
        sys_entropy=self.grid_entropy(posterior)
        self.entropy_trace.append(sys_entropy)

        sentpy_=sys_entropy

    else:
      for _ in range(step):
       
        current_step+=1
        print 'step %r' %current_step
        # 1. compute discrete forward states (randomly ordered)
        fs, key_trace=self.forward_state()

        # 2. action selection
        if method is 'random':
          fs=np.array(fs)
          rand_idx=np.random.choice(fs.shape[0], 1)
          goal_pos=list(fs[rand_idx, :][0])
          goal_act=key_trace[rand_idx]
        else:
          # compute information gain
          info_gain=self.information_gain(sentpy_, fs, method)      
          max_value=max(info_gain)
          max_index=info_gain.index(max_value)
          goal_pos=fs[max_index]  # goal position the robot will go to 
          goal_act=key_trace[max_index]
        
        goal_pos.append(self.ws.init_pos[2])
        
        if cout:
          # print out the action
          print 'next action   %r'%goal_act      
          #print 'goal position %r'%goal_pos 
        
        self.dist+=self.action_length[goal_act]

        # robot manipulation
        self.moveTo(goal=goal_pos)

        # visualization update
        self.goal_trace.append(goal_pos[0:2])

        self.simulation_loc(goal_pos=goal_pos,sim=sim,current_step=current_step,step=step)

        # update robot current position
        self.current_grid_pos=goal_pos 
        # 3. update belief   
        #
        # fetch the new measurement from sensor       
        if self.connection: 
          self.fetch_sensor_data_once()
        else: 
          m=self.proximity_generator() 
          self.ss.setProx(m)
        
        prox_new=self.ss.getProx()
        self.bayesian_update(goal_pos, prox_new, method=method)

        # update entropy 
        posterior=self.ws.grid_bk.copy()
        sys_entropy=self.grid_entropy(posterior)
        self.entropy_trace.append(sys_entropy)

        sentpy_=sys_entropy

        if cout:
            print 'sys_entropy %r'%sys_entropy
            print 'max information gain: %r' %max(info_gain)
            print '______________________________________________________'

    print 'Agent::localization::Localization finished'

    entropy_trace = np.array(self.entropy_trace) 
    grid_bk_final = self.ws.grid3D_MAP()

    return grid_bk_final,entropy_trace,self.goal_trace

  #-----------------------------------------------------------------------------------------
  # Module Visualization
  # simulating the process of active localization and active object discrimination
  #-----------------------------------------------------------------------------------------
  def simulation_loc(self, goal_pos=[0.75,0, 0.4], init=False,sim=True,current_step=0,step=0):
    '''
    visualize localization procedure
    '''
    sim_z_height = 0.1
    if sim:
      ## initilization 
      if init:
      ## figure 1: belief distribution
        matplotlib.interactive(True)
        fig1=plt.figure(1) 
        ax1=fig1.add_subplot(111, projection='3d')
        ax1.set_xlim(self.ws.init_pos[0], self.ws.init_pos[0]+self.ws.width)
        ax1.set_ylim(self.ws.init_pos[1], self.ws.init_pos[1]+self.ws.length)
        X=np.linspace(self.ws.init_pos[0], self.ws.init_pos[0]+self.ws.width, num=self.ws.grid_size[1])
        Y=np.linspace(self.ws.init_pos[1], self.ws.init_pos[1]+self.ws.length, num=self.ws.grid_size[0])   
        X, Y=np.meshgrid(X, Y)
        ax1.scatter(self.current_grid_pos[0], self.current_grid_pos[1], 1, marker='o', color='r')
        ax1.set_zlim(0, 1)
        ax1.view_init(90, 180)  # bird-view
        Z=self.ws.occ2D_bk.reshape(self.ws.grid_size[0:2])
        surf=ax1.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False) 
        plt.draw()
        time.sleep(0.05)

        surf.remove()          
        self.ax1=ax1

      ## figure 2: robot movement trace
        matplotlib.interactive(True)
        fig2=plt.figure(2) 
        ax2=fig2.add_subplot(111, projection='3d')
        ax2.set_zlim(0, sim_z_height)
        ax2.view_init(45, 45)  # side-view  
        ax2.set_xlim(self.ws.init_pos[0], self.ws.init_pos[0]+self.ws.width)
        ax2.set_ylim(self.ws.init_pos[1], self.ws.init_pos[1]+self.ws.length)
        ax2.set_xlabel('width',fontsize=25)
        ax2.set_ylabel('length',fontsize=25)
        ax2.set_zlabel('height',fontsize=25)
        X=np.linspace(self.ws.init_pos[0], self.ws.init_pos[0]+self.ws.width, num=self.ws.grid_size[1])
        Y=np.linspace(self.ws.init_pos[1], self.ws.init_pos[1]+self.ws.length, num=self.ws.grid_size[0])   
        X, Y=np.meshgrid(X, Y)
        ax2.scatter(self.current_grid_pos[0], self.current_grid_pos[1], 1, marker='o', color='r')
        
        plt.draw()
        self.ax2=ax2    

      else:
      ## figure 1
      # plot trace
        plt.figure(1) 
        self.ax1.scatter(goal_pos[0], goal_pos[1], 1, marker='o', color='r')
        x_t=[i[0] for i in self.goal_trace]
        y_t=[i[1] for i in self.goal_trace]
        z_t=[1 for _ in self.goal_trace]
        self.ax1.plot(x_t, y_t, z_t, linewidth=3.2, linestyle='-', color='y')
        
        # plot the new prior distribution
        X=np.linspace(self.ws.init_pos[0], self.ws.init_pos[0]+self.ws.width, num=self.ws.grid_size[1])
        Y=np.linspace(self.ws.init_pos[1], self.ws.init_pos[1]+self.ws.length, num=self.ws.grid_size[0])   
        X, Y=np.meshgrid(X, Y)
        Z=self.ws.occ2D_bk.reshape(self.ws.grid_size[0:2])  # update the posterior distribution
        surf=self.ax1.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm,
                 linewidth=0, antialiased=False)
        plt.draw()
        time.sleep(0.05)
        
        if current_step!=step:
          surf.remove()

      ## figure 2
        fig2=plt.figure(2,figsize=(20,20))
        self.ax2=fig2.add_subplot(111, projection='3d')
        self.ax2.set_zlim(0, sim_z_height)
        self.ax2.view_init(45, 45)  # side-view  
        self.ax2.set_xlim(self.ws.init_pos[0], self.ws.init_pos[0]+self.ws.width)
        self.ax2.set_ylim(self.ws.init_pos[1], self.ws.init_pos[1]+self.ws.length)
        self.ax2.set_xlabel('width',fontsize=25)
        self.ax2.set_ylabel('length',fontsize=25)
        self.ax2.set_zlabel('height',fontsize=25)
        X=np.linspace(self.ws.init_pos[0], self.ws.init_pos[0]+self.ws.width, num=self.ws.grid_size[1])
        Y=np.linspace(self.ws.init_pos[1], self.ws.init_pos[1]+self.ws.length, num=self.ws.grid_size[0])   
        X, Y=np.meshgrid(X, Y)  
        self.ax2.scatter(goal_pos[0], goal_pos[1], sim_z_height, marker='o', color='b',s=40)
        
        # plot trace
        x_t=[i[0] for i in self.goal_trace]
        y_t=[i[1] for i in self.goal_trace]
        z_t=[sim_z_height for _ in self.goal_trace]
        self.ax2.plot(x_t, y_t, z_t, linewidth=3.2, linestyle='-', color='b')
        
        color_map=np.linspace(0,11,11)/float(11)
        grid_max=self.ws.grid3D_MAP()

        for i in range(grid_max.shape[0]):
          if (grid_max[i,2]>0.6): #and (self.ws.height-grid_max[i,3]-self.ws.z_offset>0.03):
            x_ = grid_max[i,0] * np.ones(2)
            y_ = grid_max[i,1] * np.ones(2)
            #z_ = np.linspace(0,self.ws.height-grid_max[i,3]-self.ws.z_offset, 2)
            z_ = np.linspace(0,sensorModel.PROX_H[0]-grid_max[i,3], 2)
            #print 'z_ value',z_
            color_idx=np.ceil(grid_max[i,2]*10)
            self.ax2.plot(x_, y_, z_, linewidth=10, linestyle='-', color=[color_map[color_idx],0.2,0.2])
        #plt.savefig('exp.eps')    
        plt.draw()
        time.sleep(0.05)
        
        if current_step!=step:
          plt.gcf().clear()

  def visualize_loc_results(self):
    ## visualize the localization results
    sim_z_height = 0.1
    matplotlib.interactive(True)
    fig10=plt.figure(10)
    ax=fig10.add_subplot(111, projection='3d')
    ax.set_zlim(0, sim_z_height)
    ax.view_init(45, 60)  # side-view  
    ax.set_xlim(self.ws.init_pos[0], self.ws.init_pos[0]+self.ws.width)
    ax.set_ylim(self.ws.init_pos[1], self.ws.init_pos[1]+self.ws.length)
    X=np.linspace(self.ws.init_pos[0], self.ws.init_pos[0]+self.ws.width, num=self.ws.grid_size[1])
    Y=np.linspace(self.ws.init_pos[1], self.ws.init_pos[1]+self.ws.length, num=self.ws.grid_size[0])   
    X, Y=np.meshgrid(X, Y)  

    # plot the occ_bk
    color_map=np.linspace(0,11,11)/float(11)
    grid_max=self.ws.grid3D_MAP()
    for i in range(grid_max.shape[0]):
      if grid_max[i,2]>0.6:
        x_ = grid_max[i,0] * np.ones(2)
        y_ = grid_max[i,1] * np.ones(2)
        z_ = np.linspace(0,sensorModel.PROX_H[0]-grid_max[i,3], 2)
      
        color_idx=np.ceil(grid_max[i,2]*10)
        ax.plot(x_, y_, z_, linewidth=10, linestyle='-', color=[color_map[color_idx],0.2,0.2],alpha=0.5)
    
    # plot the explored traces
    x_t=[i[0] for i in self.goal_trace]
    y_t=[i[1] for i in self.goal_trace]
    z_t=[sim_z_height for _ in self.goal_trace]
    ax.plot(x_t, y_t, z_t, linewidth=3, linestyle='-', color='b')
    
    # plot estimated obj position
    obj_num=self.obj.num_obj
    obj_pos=self.ws.get_obj_loc()
    if obj_pos:
      for obj in obj_pos:
        rect=obj['rect']
        corner=list(rect)
        corner.append(corner[0])
        corner=np.array(corner)
        x=obj['centroid'][0]
        y=obj['centroid'][1]
        z=obj['centroid'][2]-self.ws.z_offset

        plt.plot(corner[:,0],corner[:,1],np.array([z,z,z,z,z]),linewidth=2,color='g')
        plt.plot(corner[:,0],corner[:,1],np.array([0,0,0,0,0]),linewidth=2,color='g')
        plt.plot([corner[0,0],corner[0,0]],[corner[0,1],corner[0,1]],[0,z],linewidth=2,color='g')
        plt.plot([corner[1,0],corner[1,0]],[corner[1,1],corner[1,1]],[0,z],linewidth=2,color='g')
        plt.plot([corner[2,0],corner[2,0]],[corner[2,1],corner[2,1]],[0,z],linewidth=2,color='g')
        plt.plot([corner[3,0],corner[3,0]],[corner[3,1],corner[3,1]],[0,z],linewidth=2,color='g')

        # plot k-means centroid
        ax.scatter(x,y,z, marker='o',color='b',s=80)
        ax.set_xlabel('width',fontsize=25)
        ax.set_ylabel('length',fontsize=25)
        ax.set_zlabel('height',fontsize=25)

        plt.xlabel('x')
        plt.ylabel('y')
    
    #plt.savefig('exp_results')
    matplotlib.interactive(False)
    plt.show()
    
  def visualize_obj_bk(self,prob_trace=None,action_trace=None,clear=True,step=0):
    '''
    visulizing active touch process (the evolution of object belief)
    '''
    obj_num=self.obj.num_obj
    obj_name=self.obj.object_name

    matplotlib.interactive(True)
    fig72=plt.figure(72) 
    plt.xlim((1,10))
    plt.ylim((0,1))

    t=range(len(prob_trace))
    my_xticks = action_trace
    plt.xticks(t, my_xticks,fontsize=15)
    
    colors = cm.rainbow(np.linspace(0, 1, obj_num))

    for i in range(obj_num):
      prob= np.array([j[i] for j in prob_trace])
      plt.plot(t,prob,linewidth=5,label=obj_name[i],color=colors[i])

    plt.xlabel('action sequence',fontsize=20)
    plt.ylabel('obj belief',fontsize=20)
    plt.grid(True)
    plt.legend()
    _,MAP_obj_name=self.obj.objectMAP()
    plt.title('MAP object %r' %MAP_obj_name, fontsize=20)
    #plt.savefig('obj_bk(%d).eps' %step)
    plt.draw()

    if clear:
      plt.gcf().clear()

  #-----------------------------------------------------------------------------------------
  # Module Perception
  # define interfaces with sensors and robot out, and fetching new observations
  #-----------------------------------------------------------------------------------------
  def fetch_sensor_data_once(self):
    '''
    fetch sensory data from ur robot and skincell patch only once
    '''
    prox=rospy.wait_for_message("/range_topic", Float32MultiArray)
    force=np.array(self.ss.force_sequence[-1])
    '''
    tcp_pos=rospy.wait_for_message("/Xef_w", Pose)
    accz=rospy.wait_for_message("/accz_topic", Float32MultiArray)
    '''
    # update data in sensorModel
    self.ss.setProx(np.array(prox.data))
    self.ss.setForce(force)
    '''
    self.tcp_pos=tcp_pos
    self.ss.setACCz(np.array(accz.data))
    '''

  def fetch_sensor_data_sequence(self, period, period_temp=60):
    '''
    fetch sensory data for recognizing objects
    truncate data sequence in time period: [now-period, now]
    period: time length (second) for acc, normal force
    period_temp: time length for temperature 

    return:
    normal force sequence
    accx
    accy
    accz
    temperature
    '''
    if float(period) > 16.0: #second
      rospy.logerr('Agent::fetch_sensor_data_sequence::Maximum time period of data sequence available: 16.0 sec.')
      temp_num = 1000
    else:
      freq = 250/4.0
      temp_num = int(np.ceil(freq*period))

    if float(period_temp) > 150.0: #second
      rospy.logerr('Agent::fetch_sensor_data_sequence::Maximum time period of temperature sequence available: 150.0 sec.')
      temp_num_t = 10000
    else:
      freq = 250/4.0
      temp_num_t = int(np.ceil(freq*period_temp))

    self.ss.ForceSequence = self.ss.force_sequence[-temp_num:]
    self.ss.AccXSequence = self.ss.accx_sequence[-temp_num:]
    self.ss.AccYSequence = self.ss.accy_sequence[-temp_num:]
    self.ss.AccZSequence = self.ss.accz_sequence[-temp_num:]
    self.ss.TempSequence = self.ss.temp_sequence[-temp_num_t:]

    total_force_sequence=[i.sum() for i in self.ss.ForceSequence]
    self.ss.avgForce =np.sum(np.array(total_force_sequence))/float(temp_num)

    return self.ss.ForceSequence,self.ss.AccXSequence,self.ss.AccYSequence,self.ss.AccZSequence,self.ss.TempSequence

  def force_callback(self,force_data):
    self.ss.force_sequence.append(np.array(force_data.data))
    self.ss.force_sequence = self.ss.force_sequence[1:]

  def accx_callback(self,acc):
    self.ss.accx_sequence.append(np.array(acc.data))
    self.ss.accx_sequence = self.ss.accx_sequence[1:]

  def accy_callback(self,acc):
    self.ss.accy_sequence.append(np.array(acc.data))
    self.ss.accy_sequence = self.ss.accy_sequence[1:]

  def accz_callback(self,acc):
    self.ss.accz_sequence.append(np.array(acc.data))
    self.ss.accz_sequence = self.ss.accz_sequence[1:]

  def temp_callback(self,temp_data):
    self.ss.temp_sequence.append(np.array(temp_data.data))
    self.ss.temp_sequence = self.ss.temp_sequence[1:]

  def joint_states_callback(self, data):
    for i in range(6):
      self.cbJS[i] = data.position[i]

  def end_effector_callback(self, data):
    self.cbEF[0] = data.x
    self.cbEF[1] = data.y
    self.cbEF[2] = data.z + 0.4000 # [Z_cmd = Z_cbEF + 0.400]
  
  #-----------------------------------------------------------------------------------------
  # Module Action
  # control the UR 10
  # control the movement of ur10 for searching and interacting with objects (pressing & sliding)
  #-----------------------------------------------------------------------------------------
  
  def within_tolerance(self, a_vec, b_vec):
    '''
    close-loop control the robot
    '''
    toleranceTS = [0.001, 0.001, 0.001] # tolerance is 1 mm
    # print 'Agent::within_tolerance::debugging: xyz:',a_vec,' ,actual:',self.cbEF
    for a, b, tol in zip(a_vec, b_vec, toleranceTS):
      if abs(a - b) > tol: return False
    return True

  def move_pos(self, pos, v=0.1, space='l'):
    '''
    move to a position, ONLY CONTROL ROBOT IN END-EFFECTOR POSITION
    moving position and moving speed
    pos: position list [x,y,z,rx,ry,rz]
    v: moving speed m/s
    space = 'j': call movej, space ='l',call movel
    '''
    x=pos[0]
    y=pos[1]
    z=pos[2]
    rx=pos[3]
    ry=pos[4]
    rz=pos[5]
    
    if space is 'j':
      cmd = "movej(p["+repr(x)+","+repr(y)+","+repr(z)+","+repr(rx)+","+repr(ry)+","+repr(rz)+"], v="+repr(v)+")"+"\n"
      self.s.send(cmd)
      while not self.within_tolerance([x,y,z], self.cbEF): pass

    elif space is 'l':
      cmd = "movel(p["+repr(x)+","+repr(y)+","+repr(z)+","+repr(rx)+","+repr(ry)+","+repr(rz)+"], v="+repr(v)+")"+"\n"
      self.s.send(cmd)
      while not self.within_tolerance([x,y,z], self.cbEF): pass
      
  def move_robot_home_init(self):
    if self.connection:
       ## move the robot to home position as initialization
       self.s.send("movej([0.0, -1.57, 0.0, -1.57, 0.0, 0.0], a=0.5, v=0.2, t=10, r=0)"+"\n")
       print "Robot moving to initial position for 10s..."
       time.sleep(10)
       print "At initial position! Waiting for 5s to start!"
       time.sleep(5)
       print "UR started!"

  def move_localization_init(self):
    if self.connection:
       ## move the robot to the initial position for localization
       ini_pos=list(self.ws.init_pos)+self.r_xyz
       print "ur moving to ws initial position" 
       self.move_pos(ini_pos, v = 0.2, space='j')
       print "waiting for 3s to start localization"
       time.sleep(3)
       print 'start localization!'

  def move_touching_init(self,touch_pos):
    if self.connection:
       ## move the robot to the initial position for touching
       ini_pos=list(touch_pos)+self.r_xyz
       print "ur moving to touching initial position"
       print "initial position is %r"%touch_pos
       self.move_pos(ini_pos, v=0.2, space='j')
       print "waiting for 1s to start touching"
       time.sleep(1)
       print 'start touching!'

  def moveTo(self, goal, speed=0.05):
    ''' 
    Move to a position (xyz) "goal" linearly
    by default: average speed of robot 0.05 (5cm/s)
    '''
    if self.connection:
       ## move robot to the goal position
       ur_goal_pos=list(goal)+list(self.r_xyz)
       self.move_pos(ur_goal_pos,v=speed, space='l')

  def action_pressing(self,start_pos):
    '''
    start_pos: 3D (x,y,z) position to start pressing
    '''
    pos = np.array(start_pos)
    self.current_grid_pos = pos
    # approching objects
    force=0
    #while(force<0.05):  
    while(force<0.04):
      print 'Agent::action_pressing::Approaching the object...'
      pos = np.array(self.current_grid_pos)
      self.fetch_sensor_data_once()  
      force=self.ss.getTotalForce()
      dist=self.ss.getHeightMAP()
      print 'force %r' %force
      print 'distance %r' %dist

      if dist>0.01:
        pos[2]-=0.005 #every time down 5mm with speed 10mm/s
        print 'move 0.5 cm'
        self.moveTo(goal=pos,speed=0.01)
        self.current_grid_pos=pos

      elif dist>0.002:
        pos[2]-=0.001 #every time down 1mm
        #print 'move 0.1cm'
        self.moveTo(goal=pos,speed=0.001)
        self.current_grid_pos=pos

      else:
        pos[2]-=0.0005 #every time down 0.5mm
        self.moveTo(goal=pos,speed=0.001)
        self.current_grid_pos=pos

    # pressing the object 
    print 'Pressing 2 mm deep!'
    pos[2]-=0.001
    self.moveTo(goal=pos,speed=0.001)
    self.current_grid_pos=pos
    time.sleep(3)

    # fetch data for object recognition (for 3s)
    Force,_,_,_,_ = self.fetch_sensor_data_sequence(3.0)
    print 'average total normal force'
    print self.ss.avgForce

    # move back
    print 'Move back!'
    self.moveTo(goal=start_pos,speed=0.1)
    self.current_grid_pos=start_pos
    print 'Pressing ends' 

    return Force

  def action_sliding(self,start_pos):
    pos = np.array(start_pos)
    self.current_grid_pos = pos
    time.sleep(1)
    # approching objects
    force=0
    while(force<0.2):  
      print 'Agent::action_pressing::Approaching the object...'
      pos = np.array(self.current_grid_pos)
      self.fetch_sensor_data_once()  
      force=self.ss.getTotalForce()
      dist=self.ss.getHeightMAP()
      print 'force %r' %force
      print 'distance %r' %dist

      if dist>0.01:
        pos[2]-=0.005 #every time down 5mm with speed 10mm/s
        print 'move 0.5 cm'
        self.moveTo(goal=pos,speed=0.01)
        self.current_grid_pos=pos

      elif dist>0.002:
        pos[2]-=0.001 #every time down 1mm
        #print 'move 0.1cm'
        self.moveTo(goal=pos,speed=0.001)
        self.current_grid_pos=pos

      else:
        pos[2]-=0.0005 #every time down 0.5mm
        self.moveTo(goal=pos,speed=0.001)
        self.current_grid_pos=pos
    
    
    print 'before sliding, the total force is ',force
    time.sleep(3)
    # sliding object 3cm for 3 seconds (1cm/s)
    print 'Sliding!'
    pos[1]+=0.03 # move in y-direction for 6cm
    self.moveTo(goal=pos,speed=0.03)
    self.current_grid_pos=pos
    time.sleep(3)
    # fetch new data
    Force,Accx,Accy,Accz,_ = self.fetch_sensor_data_sequence(9.0)
    
    self.ss.getSlidingFeature()
    print 'tactile descriptor'
    print self.ss.tactile_descriptor

    # move back
    time.sleep(1)
    print 'Move back!'
    self.moveTo(goal=start_pos,speed=0.1)
    self.current_grid_pos=start_pos
    print 'Sliding ends'

    return Force,Accx,Accy,Accz

  def action_static_contact(self,start_pos):
    pos = np.array(start_pos)
    self.current_grid_pos = pos
    # approching objects
    force=0
    #while(force<0.05):  
    while(force<0.04):  
      print 'Agent::action_pressing::Approaching the object...'
      pos = np.array(self.current_grid_pos)
      self.fetch_sensor_data_once()  
      force=self.ss.getTotalForce()
      dist=self.ss.getHeightMAP()
      print 'force %r' %force
      print 'distance %r' %dist

      if dist>0.01:
        pos[2]-=0.005 #every time down 5mm with speed 10mm/s
        print 'move 0.5 cm'
        self.moveTo(goal=pos,speed=0.01)
        self.current_grid_pos=pos

      elif dist>0.002:
        pos[2]-=0.001 #every time down 1mm
        #print 'move 0.1cm'
        self.moveTo(goal=pos,speed=0.001)
        self.current_grid_pos=pos

      else:
        pos[2]-=0.0005 #every time down 0.5mm
        self.moveTo(goal=pos,speed=0.001)
        self.current_grid_pos=pos

    # pressing the object 
    print 'Pressing 2 mm deep!'
    time.sleep(1)
    pos[2]-=0.001
    self.moveTo(goal=pos,speed=0.001)
    self.current_grid_pos=pos

    self.fetch_sensor_data_once()  
    force=self.ss.getTotalForce()
    print 'Now the force is',force

    print 'Recording the temperature for 15 seconds'
    time.sleep(15)
    # fetch data for temperature for 30 seconds
    Force,_,_,_,Temperature = self.fetch_sensor_data_sequence(3.0,period_temp=15)

    # move back
    print 'Move back!'
    self.moveTo(goal=start_pos,speed=0.1)
    self.current_grid_pos=start_pos
    print 'Recover the temperature for 30 seconds'
    time.sleep(30)

    print 'Temperature fetching ends' 

    return Force,Temperature



  def special_action_sliding(self,start_pos,end_pos):
    pos = np.array(start_pos)
    end_pos = np.array(end_pos)
    
    pos[2] = end_pos[2]+0.01

    self.moveTo(goal=pos,speed=0.01)
    pos[2] = end_pos[2]
    self.moveTo(goal=pos,speed=0.001)

    print 'Sliding!'
    self.moveTo(goal=end_pos,speed=0.01)

    # move back
    print 'Move back!'
    self.moveTo(goal=start_pos,speed=0.1)
    self.current_grid_pos=start_pos
    print 'Sliding ends'

  

