import numpy as np
import random
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from sklearn.cluster import KMeans
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import matplotlib.pyplot as plt
from minimum_bounding_rectangle import minimum_bounding_rectangle
import sensorModel as SM
#==================================================================================
#   Mohsen Kaboli , Technical University of Munich
#   mohsen.kaboli@tum.de
#   @2016
#==================================================================================
# define the working space for the robot to explore, the ws is a 3D cubic
# @ for real robot: set z=-0.08: 
# @ np.array([-0.35,-0.77,-0.08])
#==================================================================================

# the initial workspace position (xyz coordinate)
WS_INIT_POS = np.array([0.470,-0.465,-0.076]) # x,y,z
WS_SIZE = np.array([1.11, 0.64, 0.2]) # length, width, height
GRID_NUM = np.array([23, 27,SM.NUM_PROX_GRID]) # grid number for length, width, height 

class workspace3D:
    def __init__(self, init=WS_INIT_POS, geo=WS_SIZE, grid_num=GRID_NUM):
        '''
        init_pos: [x,y,z] of the robot initial position,
                   it is also the zero point of exploration map w.r.t base coordinate
        geo: workspace size (length, width, heigth)
        grid_num: number of grid in length, width and height
        '''
        # grid parameters (grid2D is for simple search)  
        self.init_pos=init
        self.length=geo[0]      # meter 
        self.width=geo[1]       # meter
        self.height=geo[2]      # meter
        self.grid_size=grid_num
        self.z_shift=0 #self.init_pos[2]-self.height

        self.intvl_l=self.length/(self.grid_size[0]-1.)
        self.intvl_w=self.width/(self.grid_size[1]-1.)

        self.grid, self.grid2D=self.grid_generator()
        self.grid_bk=self.grid_belief_init() 
 
        self.occ_bk, self.occ2D_bk=self.occ_belief_init(method='unif') #occupancy 

        self.obj_loc=None # object found in the working space

        #self.z_offset=0.065-self.init_pos[2] # to compensate the change of robot mapping height!
        self.z_offset=0
        
    def grid_generator(self):
        grid_l = np.linspace(self.init_pos[1], self.init_pos[1]+self.length, num=self.grid_size[0])   
        grid_w = np.linspace(self.init_pos[0], self.init_pos[0]+self.width, num=self.grid_size[1])
        #grid_h=np.linspace(self.init_pos[2], self.init_pos[2]-self.height, num=self.grid_size[2])
        grid_h = np.array(SM.PROX_H)
        grid_world = np.array([[i, j, k] for j in grid_l for i in grid_w for k in grid_h ])

        grid2D_world = np.array([[i, j] for j in grid_l for i in grid_w])
        
        return grid_world,grid2D_world
    
    def grid_belief_init(self):
        ## with no prior knowledge, more preferable to think that object height is 0.2m 
        grid_bk=(1/2.)*np.ones((self.grid.shape[0]))
        return grid_bk

    def occ_belief_init(self, method='unif'):
        occ_bk=(1/2.)*np.ones((self.grid.shape[0])) 

        if method is 'gauss': # gaussian distribution
            x_mu = np.array([i - self.ws_center()[0:2] for i in self.grid2D])
            Cov = np.matrix(((0.01, 0), (0, 0.02)))
            occ2D_bk = np.array([np.array(np.exp(-0.5 * np.matrix(j) * Cov.I * np.matrix(j).T)) for j in x_mu])
            occ2D_bk = np.squeeze(np.asarray(occ2D_bk))
            occ2D_bk = occ2D_bk / float(np.sum(occ2D_bk))

        if method is 'unif': # uniform distribution
            occ2D_bk = np.ones((self.grid_size[0]*self.grid_size[1]))        
            occ2D_bk = occ2D_bk / float(np.sum(occ2D_bk))
        
        return occ_bk, occ2D_bk
        
    def ws_center(self):
        return np.array((self.grid[0, :]+self.grid[self.grid.shape[0]-1, :])/2)

    def occ2D_bk_show(self):
        # visualize grid2D belief
        fig = plt.figure() 
        ax = fig.add_subplot(111, projection='3d')
        #ax.view_init(90,0) # bird-view
        ax.set_zlim(0,0.1)
        ax.set_xlim(self.init_pos[0] - self.width, self.init_pos[0])
        ax.set_ylim(self.init_pos[1], self.init_pos[1] + self.length)
        X = np.linspace(self.init_pos[0], self.init_pos[0] - self.width, num=self.grid_size[1])
        Y = np.linspace(self.init_pos[1], self.init_pos[1] + self.length, num=self.grid_size[0])   
        X, Y = np.meshgrid(X, Y)
        Z = self.occ2D_bk.reshape(self.grid_size[0:2])
        surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)
        plt.show()

    def grid3D_MAP(self):
        # squeeze 3D occ to 2D. The entry at each 2D occ is the MAP by 3D occ.
        # return: n*5 dim array with  1,2 column: horizontal position, 
        #                             3 column: MAP value, 
        #                             4 column: MAP height
        #                             5 column: MAP index
        grid_squeezed=np.ones((self.grid2D.shape[0],5))
        grid_h = np.array(SM.PROX_H)
        grid_bk=np.array(self.grid_bk)
        h_num=self.grid_size[2]
        for k in range(self.grid2D.shape[0]):
            pos=self.grid2D[k,:]
            priors=grid_bk[h_num*k:h_num*(k+1)]
            # MAP 
            # if all the value the same, return the last one (for the purpose of grid_bk initilization and algorithm evaluation)
            max_val=priors.max()
            max_idx=priors.argmax()
            if np.abs(max_val-0.5)<0.0001:
                max_idx=self.grid_size[2]-1
   
            grid_squeezed[k,0]=pos[0]
            grid_squeezed[k,1]=pos[1]
            grid_squeezed[k,2]=max_val
            grid_squeezed[k,3]=grid_h[max_idx]-self.z_shift
            grid_squeezed[k,4]=max_idx

        return grid_squeezed

    def object_detection(self,num_obj=1,threshold=0.6, num_points=0):
        ## clustering objects and return their centroids as well as min bounding rectangular 
        ## threshold: below this threshold data are filtered.
        ## num_points: minimul the data num for clustering
        ## 
        grid_squeezed=self.grid3D_MAP()
        grid_squeezed[:,3]=self.height-grid_squeezed[:,3]
        mask1=grid_squeezed[:,2]>threshold
        X=grid_squeezed[mask1]
        mask2=self.height-X[:,3]-self.z_offset>0.03
        Y=X[mask2]

        Y=X[:,(0,1,3)]

        if Y.shape[0]>num_points:
            # kmeans clustering 
            kmeans=KMeans(n_clusters=num_obj,max_iter=1000)
            kmeans.fit(Y)
            # clustering centroids
            centroids=kmeans.cluster_centers_
            # return the highst position of a cluster
            labels=kmeans.labels_
        
            obj_info=[]
            for k in range(num_obj):
                mask3=labels==k
                pos_=Y[mask3,:]
                pos2D=pos_[:,(0,1)]
                bounding_rect=minimum_bounding_rectangle(pos2D)
                
                new_dict={}
                new_dict['idx']=k
                new_dict['centroid']=centroids[k]
                new_dict['rect']=bounding_rect


                obj_info.append(new_dict)

            self.obj_loc=list(obj_info)
            ret=True

        else:
            self.obj_loc=None
            ret=False

        return ret

    def get_obj_loc(self):
        return self.obj_loc




    




  
         

