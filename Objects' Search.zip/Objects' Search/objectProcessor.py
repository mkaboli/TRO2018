import numpy as np
import random
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import matplotlib.pyplot as plt
from scipy.stats import norm
from Object import Object

#==================================================================================
# objectlist: all the objects information (prior knowledge)
# object processing: calculate the posterior of object based on Bayesian inference, store the current robot belief of the object

# Author: Mohsen Kaboli 
# mohsen.kaboli.tum.de
# @2016
#==================================================================================
class objectProcessor:
    def __init__(self):
        self.num_obj=6
        self.obj1=Object(mu={'force':0.4017,'actx':0.0002032},sigma={'force':0.0932,'actx':0.00003417})
        self.obj2=Object(mu={'force':0.8501,'actx':0.0003719},sigma={'force':0.0665,'actx':0.00003995})
        self.obj3=Object(mu={'force':0.9825,'actx':0.0002922},sigma={'force':0.0627,'actx':0.00003365})
        self.obj4=Object(mu={'force':1.0847,'actx':0.0004012},sigma={'force':0.0721,'actx':0.00003417})
        self.obj5=Object(mu={'force':0.4856,'actx':0.0003170},sigma={'force':0.0522,'actx':0.00002686})
        self.obj6=Object(mu={'force':0.8763,'actx':0.0004605},sigma={'force':0.0901,'actx':0.00004614})
        
        self.object_name=['obj1','obj2','obj3','obj4','obj5','obj6']
        self.object_list=[self.obj1,self.obj2,self.obj3,self.obj4,self.obj5,self.obj6]

        self.Mu_press=np.array([i.mu['force'] for i in self.object_list])
        self.Sigma_press=np.array([i.sigma['force'] for i in self.object_list])

        self.Mu_slide=np.array([i.mu['actx'] for i in self.object_list])
        self.Sigma_slide=np.array([i.sigma['actx'] for i in self.object_list])

        ## confusion matrix (Bayesian Exploration methodology)
        self.CM=self.CM_init()

        ## object belief (prior and posterior)
        self.obj_posterior=(1/float(self.num_obj))*np.ones((self.num_obj))
        self.obj_prior=(1/float(self.num_obj))*np.ones((self.num_obj))
    
    def CM_init(self):
        '''
        building confusion matrix for bayesian exploration methodology
        '''
        # for pressing
        CM_press=np.ones((self.num_obj,self.num_obj))
        Mu=self.Mu_press
        Sigma=self.Sigma_press

        for i in range(self.num_obj):
            for j in range(self.num_obj):
                CM_press[i,j]=np.sqrt(2*Sigma[i]*Sigma[j]/(np.power(Sigma[i],2)+np.power(Sigma[j],2))) * \
                        np.exp((-1/4.)*np.power((Mu[i]-Mu[j]),2)/(np.power(Sigma[i],2)+np.power(Sigma[j],2)))

                if CM_press[i,j]<0.0001:
                    CM_press[i,j]=0.0001

                if CM_press[i,j]>0.9999:
                    CM_press[i,j]=0.9999

        
        # for sliding
        CM_slide=np.ones((self.num_obj,self.num_obj))
        Mu=self.Mu_slide
        Sigma=self.Sigma_slide

        for i in range(self.num_obj):
            for j in range(self.num_obj):
                CM_slide[i,j]=np.sqrt(2*Sigma[i]*Sigma[j]/(np.power(Sigma[i],2)+np.power(Sigma[j],2))) * \
                        np.exp((-1/4.)*np.power((Mu[i]-Mu[j]),2)/(np.power(Sigma[i],2)+np.power(Sigma[j],2)))

                if CM_slide[i,j]<0.0001:
                    CM_slide[i,j]=0.0001

        CM={'press':CM_press,'slide':CM_slide}

        return CM

    def obj_observation(self,data,action='press'):
        '''
        calculate the observation of objects P(X|Z)
        the observation is based on univariate Gaussian Distribution
        '''
        if action is 'press':
            Mu=self.Mu_press
            Sigma=self.Sigma_press

        elif action is 'slide':
            Mu=self.Mu_slide
            Sigma=self.Sigma_slide

        #obs_prob= Gaussian distribution in numpy! setting those of 0 to 0.001, 1 to 0.999
        obs_prob=norm(Mu, Sigma).pdf(data)
        obs_prob[obs_prob<0.001]=0.001

        return obs_prob

    def bk_update(self,data,action='press'):
        '''
        update the posterior via Bayesian rule
        '''
        obs_prob=self.obj_observation(data,action)
        
        total=np.dot(obs_prob,self.obj_prior)
        if total<0.001:
            total=0.001

        self.obj_posterior=obs_prob*self.obj_prior/float(total)

        self.obj_prior=self.obj_posterior.copy()


    def action_selection(self,num_press=1,num_slide=1):
        # predicted uncertainty
        CM_press=self.CM['press']
        CM_slide=self.CM['slide']

        up=0
        us=0
        for i in range(self.num_obj):
            p=np.power(self.obj_posterior[i],2)/np.dot(CM_press[i,:],self.obj_posterior)
            s=np.power(self.obj_posterior[i],2)/np.dot(CM_slide[i,:],self.obj_posterior)
            up+=p
            us+=s
        
        U_p=1-up
        U_s=1-us    

        # benefit
        bef_press=1-np.power(U_p,1/float(num_press))
        bef_slide=1-np.power(U_s,1/float(num_slide))

        # decision
        if bef_press>=bef_slide:
            action='press'
        else:
            action='slide' 

        return action

    def objectMAP(self):
        '''
        return the most possible object and its belief based on MAP
        '''
        max_idx=self.obj_posterior.argmax()
        max_val=self.obj_posterior.max()

        return max_val,self.object_name[max_idx]

    def get_obj_bk(self):
        return self.obj_posterior, self.object_name

    def obj_bk_reset(self):
        self.obj_posterior=(1/float(self.num_obj))*np.ones((self.num_obj))
        self.obj_prior=(1/float(self.num_obj))*np.ones((self.num_obj))



       
        