#!/usr/bin/env python
import numpy as np
import time
import matplotlib
import matplotlib.pyplot as plt
import glob
from mpl_toolkits.mplot3d import Axes3D
from sklearn.cluster import KMeans
from minimum_bounding_rectangle import minimum_bounding_rectangle


#==================================================================================
# Created by Mohsen Kaboli 
# mohsen.kaboli@tum.de
# @2016
# Plot the results of mapping, 
# k-MEANS clustering
#==================================================================================

grid_max = np.loadtxt('grid_bk.txt')
goal_trace = np.loadtxt('goal_trace.txt')

def object_detection(num_obj=1,threshold=0.6, num_points=0):
    ## clustering objects and return their centroids as well as min bounding rectangular 
    ## threshold: below this threshold data are filtered.
    ## num_points: minimul the data num for clustering
    ## 
    grid_squeezed=grid_max
    mask1=grid_squeezed[:,2]>threshold
    X=grid_squeezed[mask1]

    Y=X[:,(0,1,3)]

    if Y.shape[0]>num_points:
        # kmeans clustering 
        kmeans=KMeans(n_clusters=num_obj,max_iter=1000)
        kmeans.fit(Y)
        # clustering centroids
        centroids=kmeans.cluster_centers_
        # return the highst position of a cluster
        labels=kmeans.labels_
    
        obj_info=[]
        for k in range(num_obj):
            mask3=labels==k
            pos_=Y[mask3,:]
            pos2D=pos_[:,(0,1)]
            bounding_rect=minimum_bounding_rectangle(pos2D)
            
            new_dict={}
            new_dict['idx']=k
            new_dict['centroid']=centroids[k]
            new_dict['rect']=bounding_rect


            obj_info.append(new_dict)

        obj_loc=list(obj_info)

    return obj_loc


## plotting the results
fig1=plt.figure(1) 
ax=fig1.add_subplot(111, projection='3d')
ax.view_init(45, 45)
color_map=np.linspace(0,11,11)/float(11)
z_max = 0
sim_z_height = 0.1 
for i in range(grid_max.shape[0]):
	if grid_max[i,2]>0.6:
		x_ = grid_max[i,0] * np.ones(2)
		y_ = grid_max[i,1] * np.ones(2)
		z_ = np.linspace(0,0.05-grid_max[i,3], 2)
		color_idx=np.ceil(grid_max[i,2]*10)
		ax.plot(x_, y_, z_, linewidth=30, linestyle='-', color=[color_map[color_idx],0.2,0.2])

# plot the explored traces
x_t=[i[0] for i in goal_trace]
y_t=[i[1] for i in goal_trace]
z_t=[sim_z_height for _ in goal_trace]
ax.plot(x_t, y_t, z_t, linewidth=3, linestyle='-', color='b')

# plot estimated obj position
obj_pos=object_detection(num_obj=9,threshold=0.6, num_points=0)

for obj in obj_pos:
	rect=obj['rect']
	corner=list(rect)
	corner.append(corner[0])
	corner=np.array(corner)
	x=obj['centroid'][0]
	y=obj['centroid'][1]
	z=0.05-obj['centroid'][2]
	plt.plot(corner[:,0],corner[:,1],np.array([z,z,z,z,z]),linewidth=2,color='g')
	plt.plot(corner[:,0],corner[:,1],np.array([0,0,0,0,0]),linewidth=2,color='g')
	plt.plot([corner[0,0],corner[0,0]],[corner[0,1],corner[0,1]],[0,z],linewidth=2,color='g')
	plt.plot([corner[1,0],corner[1,0]],[corner[1,1],corner[1,1]],[0,z],linewidth=2,color='g')
	plt.plot([corner[2,0],corner[2,0]],[corner[2,1],corner[2,1]],[0,z],linewidth=2,color='g')
	plt.plot([corner[3,0],corner[3,0]],[corner[3,1],corner[3,1]],[0,z],linewidth=2,color='g')

	# plot k-means centroid
	ax.scatter(x,y,z, marker='o',color='b',s=80)
	ax.set_xlabel('width',fontsize=25)
	ax.set_ylabel('length',fontsize=25)
	ax.set_zlabel('height',fontsize=25)

plt.xlabel('x')
plt.ylabel('y')

plt.show()